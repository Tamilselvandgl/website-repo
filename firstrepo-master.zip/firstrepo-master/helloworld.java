//your first java program
class Helloworld{
    public static void main(String[] args) {
        System.out.println("Hello World!!! program da dei mandaya ");
    }
}

// javac helloworld.java
